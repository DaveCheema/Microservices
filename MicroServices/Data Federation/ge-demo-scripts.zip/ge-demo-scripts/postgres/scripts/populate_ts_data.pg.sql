TRUNCATE TABLE public.ts_data;
INSERT INTO public.ts_data(tag, "time", measurement)
SELECT DISTINCT tag_name, epoch_time_ms, measurement
FROM public.transform_imported_data_to_timeseries_compatible_data();