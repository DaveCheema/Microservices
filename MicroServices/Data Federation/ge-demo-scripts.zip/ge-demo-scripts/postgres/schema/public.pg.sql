CREATE SCHEMA IF NOT EXISTS public
    AUTHORIZATION admin;

COMMENT ON SCHEMA public
    IS 'standard public schema';

GRANT ALL ON SCHEMA public TO admin;

GRANT ALL ON SCHEMA public TO PUBLIC;