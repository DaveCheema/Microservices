DROP FUNCTION IF EXISTS public.transform_to_predix(bigint, bigint, bigint);

CREATE FUNCTION public.transform_to_predix(
	start_time bigint,
	end_time bigint,
	per_tag_limit bigint)
    RETURNS json
    LANGUAGE 'plpgsql'
    COST 100.0

AS $function$

DECLARE retval text :='';
DECLARE tag_name text :='';
DECLARE time_val bigint;
DECLARE measurement_val double precision;
BEGIN
	retval := '{' || E'\r\n';
	retval := retval || '"messageId":"' || CAST(9223372036854775807 * random() AS bigint) || '",' || E'\r\n';
  	retval := retval || E'\r\n' || '"body":' || E'\r\n' || '[' || E'\r\n';

    FOR tag_name in 
    	SELECT DISTINCT CAST(tag AS TEXT)
        FROM public.ts_data
        ORDER BY tag
    LOOP
    	retval := retval || E'\t' || '{' || E'\r\n';
        retval := retval || E'\t\t' || '"name":"' || tag_name || E'",\r\n';
        retval := retval || E'\t\t' || '"datapoints":[' || E'\r\n';
        
        FOR time_val, measurement_val in 
           SELECT  "time", measurement
                FROM public.ts_data
                WHERE tag =tag_name
                AND "time" BETWEEN start_time AND end_time
                ORDER BY "time" DESC
                LIMIT per_tag_limit
        LOOP
        	retval := retval || E'\t\t\t' || '[' || '"' || time_val || '"' || ',' || '"' || measurement_val || '"' || ',"3"' || '],' || E'\r\n';
        END LOOP;
        retval := left(retval, length(retval)-3); /* chop off trailing comma from last element */
		retval := retval || E'\r\n\t\t' || ']' || E'\r\n'; /* end datapoints array */
        retval := retval || E'\r\n\t' || '},' || E'\r\n';
        
    END LOOP;
    retval := left(retval, length(retval)-3);  /* chop off trailing comma from last element */
	retval := retval || E'\r\n' || ']' || E'\r\n'; /* end body array */
	retval := retval || '}' || E'\r\n';

	return to_json(retval);
    
END;

$function$;

ALTER FUNCTION public.transform_to_predix(bigint, bigint, bigint)
    OWNER TO admin;
