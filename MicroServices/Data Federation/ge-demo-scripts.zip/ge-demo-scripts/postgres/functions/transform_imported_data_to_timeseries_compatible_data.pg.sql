DROP FUNCTION IF EXISTS public.transform_imported_data_to_timeseries_compatible_data();

CREATE FUNCTION public.transform_imported_data_to_timeseries_compatible_data(
	)
    RETURNS TABLE(epoch_time_ms bigint, tag_name text, measurement double precision)
    LANGUAGE 'plpgsql'
    COST 100.0

AS $function$

DECLARE tag text:='';
BEGIN
	FOR tag IN 
        SELECT keyName FROM 
        (
            SELECT DISTINCT (keyName) AS keyName FROM
            (
                SELECT json_object_keys(data) AS keyName
                FROM (SELECT data FROM import) imported
            ) distinctKeyNames
            WHERE lower(keyName) NOT IN ('timestamp')
        ) sortableKeyNames
        ORDER BY LOWER(keyName)
    LOOP
        RETURN QUERY 
            SELECT 
            	CAST(ROUND(EXTRACT(EPOCH FROM CAST(data->>'TimeStamp' AS TIMESTAMP)) * 1000) AS BIGINT) AS epoch_time_ms,
				tag AS tag_name, 
            	CAST (data->>tag AS double precision) AS measurement
            FROM import; 
	END LOOP;
END;

$function$;

ALTER FUNCTION public.transform_imported_data_to_timeseries_compatible_data()
    OWNER TO admin;
