
DROP TABLE IF EXISTS public.import;

CREATE TABLE public.import
(
    data json NOT NULL
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.import
    OWNER to admin;