DROP TABLE IF EXISTS public.ts_data;

CREATE TABLE public.ts_data
(
    tag text COLLATE "default".pg_catalog NOT NULL,
    "time" bigint NOT NULL,
    measurement double precision NOT NULL,
    CONSTRAINT ts_data_pkey PRIMARY KEY ("time", tag)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.ts_data
    OWNER to admin;