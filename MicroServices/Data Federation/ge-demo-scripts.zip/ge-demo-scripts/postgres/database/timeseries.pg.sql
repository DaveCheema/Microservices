DROP DATABASE IF EXISTS timeseries;

CREATE DATABASE timeseries
    WITH 
    OWNER = admin
    ENCODING = 'UTF8'
    LC_COLLATE = 'C'
    LC_CTYPE = 'C'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1;